package com.example.weather

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Build
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale

object LocationProvider {
    private fun granted(c: Context, p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    fun hasForeground(c: Context) =
        granted(c, Manifest.permission.ACCESS_COARSE_LOCATION) ||
            granted(c, Manifest.permission.ACCESS_FINE_LOCATION)

    fun hasBackground(c: Context) =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            granted(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION)

    @SuppressLint("MissingPermission")
    suspend fun current(c: Context): Pair<Double, Double>? {
        if (!hasForeground(c)) return null
        val client = LocationServices.getFusedLocationProviderClient(c)
        val loc = withTimeoutOrNull(12_000) {
            try {
                client.getCurrentLocation(
                    Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                    CancellationTokenSource().token,
                ).await()
            } catch (e: Exception) {
                null
            }
        } ?: try {
            client.lastLocation.await()
        } catch (e: Exception) {
            null
        }
        return loc?.let { it.latitude to it.longitude }
    }

    suspend fun placeName(c: Context, lat: Double, lon: Double): String =
        withContext(Dispatchers.IO) {
            try {
                if (!Geocoder.isPresent()) return@withContext "Your location"
                @Suppress("DEPRECATION")
                val a = Geocoder(c, Locale.getDefault()).getFromLocation(lat, lon, 1)?.firstOrNull()
                a?.locality ?: a?.subAdminArea ?: a?.adminArea ?: "Your location"
            } catch (e: Exception) {
                "Your location"
            }
        }
}

object WeatherRefresher {
    /** Gets the location, downloads current weather, caches it and refreshes every widget. */
    suspend fun refresh(c: Context): WeatherSnapshot? {
        val ctx = c.applicationContext
        return try {
            val cached = WeatherStore.load(ctx)
            val (lat, lon) = LocationProvider.current(ctx)
                ?: cached?.let { it.lat to it.lon }
                ?: return null
            val sameSpot = cached != null &&
                kotlin.math.abs(cached.lat - lat) < 0.05 && kotlin.math.abs(cached.lon - lon) < 0.05
            val place = if (sameSpot) cached!!.place else LocationProvider.placeName(ctx, lat, lon)
            val snap = WeatherApi.fetch(lat, lon, place)
            WeatherStore.save(ctx, snap)
            WeatherWidgetProvider.updateAll(ctx, snap)
            snap
        } catch (e: Exception) {
            null
        }
    }
}
