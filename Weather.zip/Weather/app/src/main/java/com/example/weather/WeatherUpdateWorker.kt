package com.example.weather

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class WeatherUpdateWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        WeatherRefresher.refresh(applicationContext)
        return Result.success()
    }

    companion object {
        private val online = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

        fun schedulePeriodic(c: Context) {
            val req = PeriodicWorkRequestBuilder<WeatherUpdateWorker>(30, TimeUnit.MINUTES)
                .setConstraints(online).build()
            WorkManager.getInstance(c).enqueueUniquePeriodicWork(
                "weather_periodic", ExistingPeriodicWorkPolicy.KEEP, req,
            )
        }

        fun refreshNow(c: Context) {
            val req = OneTimeWorkRequestBuilder<WeatherUpdateWorker>().setConstraints(online).build()
            WorkManager.getInstance(c).enqueueUniqueWork("weather_now", ExistingWorkPolicy.REPLACE, req)
        }
    }
}
